<?php
// ============================================================
//  register.php
// ============================================================
session_start();
if (isset($_SESSION['usuario_id'])) {
    header('Location: ' . ($_SESSION['rol'] === 'admin' ? 'admin.php' : 'index.php'));
    exit;
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'db.php';
    $nombre   = trim($_POST['nombre']    ?? '');
    $telefono = trim($_POST['telefono']  ?? '');
    $pass     = $_POST['password']       ?? '';
    $pass2    = $_POST['password2']      ?? '';

    if (!$nombre || !$telefono || !$pass || !$pass2) {
        $error = 'Completa todos los campos.';
    } elseif (strlen($pass) < 6) {
        $error = 'La contraseña debe tener al menos 6 caracteres.';
    } elseif ($pass !== $pass2) {
        $error = 'Las contraseñas no coinciden.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare('SELECT id FROM usuarios WHERE nombre = ? LIMIT 1');
        $stmt->execute([$nombre]);
        if ($stmt->fetch()) {
            $error = 'Ese nombre de usuario ya está en uso.';
        } else {
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $ins  = $db->prepare('INSERT INTO usuarios (nombre, telefono, password, rol) VALUES (?, ?, ?, \'cliente\')');
            $ins->execute([$nombre, $telefono, $hash]);
            $success = '¡Cuenta creada exitosamente!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Flor & Alma – Registro</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="auth-deco">
    <span>🌷</span><span>🌸</span><span>🌺</span><span>🌼</span><span>💐</span>
  </div>
  <div class="auth-card">
    <div class="auth-logo">
      <span class="flower-icon">🌷</span>
      <h1>Crear Cuenta</h1>
      <p>Únete a Flor &amp; Alma</p>
    </div>

    <?php if ($error): ?>
      <div class="msg-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
      <div class="msg-success">
        <?= htmlspecialchars($success) ?>
        – <a href="login.php">Inicia sesión aquí</a>
      </div>
    <?php endif; ?>

    <?php if (!$success): ?>
    <form method="POST" action="register.php">
      <div class="form-group">
        <label>Nombre completo</label>
        <input type="text" name="nombre" placeholder="Tu nombre..." required
               value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Teléfono</label>
        <input type="tel" name="telefono" placeholder="33 1234 5678" required
               value="<?= htmlspecialchars($_POST['telefono'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Contraseña</label>
        <input type="password" name="password" placeholder="Mínimo 6 caracteres" required>
      </div>
      <div class="form-group">
        <label>Confirmar contraseña</label>
        <input type="password" name="password2" placeholder="Repite tu contraseña" required>
      </div>
      <button type="submit" class="btn-main">Registrarme 🌺</button>
    </form>
    <?php endif; ?>

    <p class="auth-switch">¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
  </div>
</div>
</body>
</html>
