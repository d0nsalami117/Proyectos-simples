<?php
// ============================================================
//  login.php
// ============================================================
session_start();
if (isset($_SESSION['usuario_id'])) {
    header('Location: ' . ($_SESSION['rol'] === 'admin' ? 'admin.php' : 'index.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'db.php';
    $nombre = trim($_POST['nombre'] ?? '');
    $pass   = $_POST['password'] ?? '';

    if ($nombre && $pass) {
        $db   = getDB();
        $stmt = $db->prepare('SELECT * FROM usuarios WHERE nombre = ? LIMIT 1');
        $stmt->execute([$nombre]);
        $user = $stmt->fetch();

        if ($user && password_verify($pass, $user['password'])) {
            $_SESSION['usuario_id'] = $user['id'];
            $_SESSION['nombre']     = $user['nombre'];
            $_SESSION['rol']        = $user['rol'];
            header('Location: ' . ($user['rol'] === 'admin' ? 'admin.php' : 'index.php'));
            exit;
        } else {
            $error = 'Usuario o contraseña incorrectos.';
        }
    } else {
        $error = 'Completa todos los campos.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Flor & Alma – Iniciar Sesión</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="auth-deco">
    <span>🌸</span><span>🌺</span><span>🌷</span><span>🌼</span><span>💐</span>
  </div>
  <div class="auth-card">
    <div class="auth-logo">
      <span class="flower-icon">💐</span>
      <h1>Flor &amp; Alma</h1>
      <p>Florería Artesanal</p>
    </div>

    <?php if ($error): ?>
      <div class="msg-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
      <div class="form-group">
        <label>Nombre de usuario</label>
        <input type="text" name="nombre" placeholder="Tu nombre..." required
               value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Contraseña</label>
        <input type="password" name="password" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn-main">Entrar 🌸</button>
    </form>

    <p class="auth-switch">¿No tienes cuenta? <a href="register.php">Regístrate aquí</a></p>
  </div>
</div>
</body>
</html>
