<?php
// ============================================================
//  admin.php – Panel de administración
// ============================================================
session_start();
if (!isset($_SESSION['usuario_id']))  { header('Location: login.php'); exit; }
if ($_SESSION['rol'] !== 'admin')     { header('Location: index.php'); exit; }

require_once 'db.php';
$db  = getDB();
$tab = $_GET['tab'] ?? 'pedidos';
$msg = '';

// ── Acciones POST ────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    // Cambiar estado de pedido
    if ($accion === 'estado_pedido') {
        $id     = (int)$_POST['pedido_id'];
        $estado = $_POST['estado'];
        if (in_array($estado, ['completado','cancelado'])) {
            $db->prepare('UPDATE pedidos SET estado = ? WHERE id = ?')->execute([$estado, $id]);
        }
        header('Location: admin.php?tab=pedidos&ok=estado');
        exit;
    }

    // Reabastecer ramo
    if ($accion === 'reabastecer') {
        $id  = (int)$_POST['ramo_id'];
        $qty = max(1, (int)$_POST['cantidad']);
        $db->prepare('UPDATE ramos SET stock = stock + ?, stock_max = GREATEST(stock_max, stock + ?) WHERE id = ?')
           ->execute([$qty, $qty, $id]);
        header('Location: admin.php?tab=inventario&ok=restock');
        exit;
    }

    // Editar ramo
    if ($accion === 'editar_ramo') {
        $id     = (int)$_POST['ramo_id'];
        $nombre = trim($_POST['nombre']);
        $desc   = trim($_POST['descripcion']);
        $emoji  = trim($_POST['emoji']) ?: '💐';
        $precio = (float)$_POST['precio'];

        $imagenSql = '';
        $params    = [$nombre, $desc, $emoji, $precio];

        // Subida de imagen
        if (!empty($_FILES['imagen']['name'])) {
            $ext      = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
            $allowed  = ['jpg','jpeg','png','webp','gif'];
            if (in_array($ext, $allowed)) {
                if (!is_dir('uploads')) mkdir('uploads', 0755, true);
                $fname = 'ramo_' . $id . '_' . time() . '.' . $ext;
                move_uploaded_file($_FILES['imagen']['tmp_name'], 'uploads/' . $fname);
                $imagenSql = ', imagen = ?';
                $params[]  = $fname;
            }
        }

        $params[] = $id;
        $db->prepare("UPDATE ramos SET nombre = ?, descripcion = ?, emoji = ?, precio = ? {$imagenSql} WHERE id = ?")
           ->execute($params);
        header('Location: admin.php?tab=catalogo&ok=editado');
        exit;
    }
}

// ── Datos ────────────────────────────────────────────────────
$pedidos  = $db->query('
    SELECT p.*, u.nombre AS cliente, r.nombre AS ramo_nombre, r.emoji
    FROM pedidos p
    JOIN usuarios u ON u.id = p.usuario_id
    JOIN ramos    r ON r.id = p.ramo_id
    ORDER BY p.id DESC
')->fetchAll();

$ramos    = $db->query('SELECT * FROM ramos WHERE activo = 1 ORDER BY id')->fetchAll();
$usuarios = $db->query('
    SELECT u.*, COUNT(p.id) AS num_pedidos
    FROM usuarios u
    LEFT JOIN pedidos p ON p.usuario_id = u.id
    GROUP BY u.id ORDER BY u.id
')->fetchAll();

// Stats
$totalPedidos = count($pedidos);
$totalVentas  = array_sum(array_column($pedidos, 'total'));
$totalClientes= count(array_filter($usuarios, fn($u) => $u['rol'] === 'cliente'));
$stockBajo    = count(array_filter($ramos, fn($r) => $r['stock'] <= 5));

// Ramo a editar (si viene por GET)
$ramoEdit = null;
if ($tab === 'catalogo' && isset($_GET['editar'])) {
    $s = $db->prepare('SELECT * FROM ramos WHERE id = ? LIMIT 1');
    $s->execute([(int)$_GET['editar']]);
    $ramoEdit = $s->fetch();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Flor & Alma – Admin</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="nav-logo"><span>💐</span> Flor &amp; Alma</div>
  <div class="nav-links">
    <a href="admin.php?tab=pedidos"    class="nav-btn <?= $tab==='pedidos'    ? 'active':'' ?>">📋 Pedidos</a>
    <a href="admin.php?tab=inventario" class="nav-btn <?= $tab==='inventario' ? 'active':'' ?>">📦 Inventario</a>
    <a href="admin.php?tab=usuarios"   class="nav-btn <?= $tab==='usuarios'   ? 'active':'' ?>">👥 Usuarios</a>
    <a href="admin.php?tab=catalogo"   class="nav-btn <?= $tab==='catalogo'   ? 'active':'' ?>">🌸 Catálogo</a>
    <div class="nav-user" style="margin-left:8px;">
      <div class="avatar" style="background:#f9d8e5;color:#c0527a;">A</div>
      <span>Admin</span>
    </div>
    <a href="logout.php" class="nav-btn logout">Salir 👋</a>
  </div>
</nav>

<div class="page-content">

  <!-- STATS -->
  <div class="stats-row">
    <div class="stat-card"><div class="stat-icon">📋</div><div class="stat-label">Total Pedidos</div><div class="stat-value"><?= $totalPedidos ?></div></div>
    <div class="stat-card"><div class="stat-icon">💰</div><div class="stat-label">Ventas Totales</div><div class="stat-value">$<?= number_format($totalVentas, 2) ?></div></div>
    <div class="stat-card"><div class="stat-icon">👥</div><div class="stat-label">Clientes</div><div class="stat-value"><?= $totalClientes ?></div></div>
    <div class="stat-card"><div class="stat-icon">⚠️</div><div class="stat-label">Stock Bajo</div><div class="stat-value"><?= $stockBajo ?></div></div>
  </div>

  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-ok" id="alert-msg">✅
      <?php
        $msgs = ['estado'=>'Estado actualizado.','restock'=>'Inventario reabastecido.','editado'=>'Ramo actualizado.'];
        echo $msgs[$_GET['ok']] ?? 'Acción realizada.';
      ?>
    </div>
  <?php endif; ?>

  <!-- ═══ TAB: PEDIDOS ═══ -->
  <?php if ($tab === 'pedidos'): ?>
  <div class="table-wrap">
    <div class="table-header">
      <h3>📋 Pedidos de Clientes</h3>
      <span style="font-size:13px;color:var(--texto-muted);"><?= $totalPedidos ?> pedido(s)</span>
    </div>
    <table>
      <thead>
        <tr><th>#</th><th>Cliente</th><th>Ramo</th><th>Cantidad</th><th>Total</th><th>Fecha</th><th>Estado</th><th>Acción</th></tr>
      </thead>
      <tbody>
        <?php if (!$pedidos): ?>
          <tr><td colspan="8" style="text-align:center;padding:32px;color:var(--texto-muted);">No hay pedidos todavía 🌸</td></tr>
        <?php endif; ?>
        <?php foreach ($pedidos as $p): ?>
        <tr>
          <td><strong>#<?= $p['id'] ?></strong></td>
          <td><?= htmlspecialchars($p['cliente']) ?></td>
          <td><?= $p['emoji'] ?> <?= htmlspecialchars($p['ramo_nombre']) ?></td>
          <td><?= $p['cantidad'] ?> ramo(s)</td>
          <td><strong>$<?= number_format($p['total'], 2) ?></strong></td>
          <td style="font-size:13px;color:var(--texto-muted);"><?= date('d/m/Y H:i', strtotime($p['creado_en'])) ?></td>
          <td><span class="badge badge-<?= $p['estado'] ?>"><?= ucfirst($p['estado']) ?></span></td>
          <td>
            <?php if ($p['estado'] === 'pendiente'): ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="accion"    value="estado_pedido">
              <input type="hidden" name="pedido_id" value="<?= $p['id'] ?>">
              <input type="hidden" name="estado"    value="completado">
              <button type="submit" class="btn-sm btn-verde">✓ Listo</button>
            </form>
            <form method="POST" style="display:inline;margin-left:4px;">
              <input type="hidden" name="accion"    value="estado_pedido">
              <input type="hidden" name="pedido_id" value="<?= $p['id'] ?>">
              <input type="hidden" name="estado"    value="cancelado">
              <button type="submit" class="btn-sm btn-outline-rosa">✕ Cancelar</button>
            </form>
            <?php else: ?>–<?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- ═══ TAB: INVENTARIO ═══ -->
  <?php elseif ($tab === 'inventario'): ?>
  <h3 class="section-title">📦 Existencias de Ramos</h3>
  <div class="inventory-grid">
    <?php foreach ($ramos as $r):
      $pct      = $r['stock_max'] > 0 ? min(100, round(($r['stock'] / $r['stock_max']) * 100)) : 0;
      $barClass = $pct <= 10 ? 'critical' : ($pct <= 30 ? 'low' : '');
    ?>
    <div class="inv-card">
      <span class="inv-emoji"><?= $r['emoji'] ?></span>
      <div class="inv-name"><?= htmlspecialchars($r['nombre']) ?></div>
      <div class="inv-stock-label"><?= $r['stock'] ?> / <?= $r['stock_max'] ?> unidades (<?= $pct ?>%)</div>
      <div class="inv-stock-bar-wrap">
        <div class="inv-stock-bar <?= $barClass ?>" style="width:<?= $pct ?>%"></div>
      </div>
      <form method="POST" style="display:flex;gap:8px;align-items:center;">
        <input type="hidden" name="accion"  value="reabastecer">
        <input type="hidden" name="ramo_id" value="<?= $r['id'] ?>">
        <input type="number" name="cantidad" value="20" min="1" max="500"
               style="width:80px;padding:7px 10px;border-radius:9px;border:1.5px solid var(--border);font-size:13px;">
        <button type="submit" class="btn-sm btn-rosa" style="flex:1;">+ Agregar</button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- ═══ TAB: USUARIOS ═══ -->
  <?php elseif ($tab === 'usuarios'): ?>
  <div class="table-wrap">
    <div class="table-header"><h3>👥 Usuarios Registrados</h3></div>
    <table>
      <thead><tr><th>ID</th><th>Nombre</th><th>Teléfono</th><th>Rol</th><th>Pedidos</th><th>Registrado</th></tr></thead>
      <tbody>
        <?php foreach ($usuarios as $u): ?>
        <tr>
          <td>#<?= $u['id'] ?></td>
          <td><strong><?= htmlspecialchars($u['nombre']) ?></strong></td>
          <td><?= htmlspecialchars($u['telefono'] ?? '–') ?></td>
          <td><span class="badge <?= $u['rol']==='admin' ? 'badge-completado' : 'badge-pendiente' ?>"><?= $u['rol'] ?></span></td>
          <td><?= $u['num_pedidos'] ?> pedido(s)</td>
          <td style="font-size:13px;color:var(--texto-muted);"><?= date('d/m/Y', strtotime($u['creado_en'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- ═══ TAB: CATÁLOGO ═══ -->
  <?php elseif ($tab === 'catalogo'): ?>

  <?php if ($ramoEdit): ?>
  <!-- Formulario editar -->
  <div class="table-wrap" style="max-width:540px; margin-bottom:28px;">
    <div class="table-header">
      <h3>✏️ Editar: <?= htmlspecialchars($ramoEdit['nombre']) ?></h3>
      <a href="admin.php?tab=catalogo" style="font-size:13px;color:var(--texto-muted);">← Volver</a>
    </div>
    <div style="padding:24px;">
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="accion"  value="editar_ramo">
        <input type="hidden" name="ramo_id" value="<?= $ramoEdit['id'] ?>">
        <div class="form-group">
          <label>Emoji</label>
          <input type="text" name="emoji" value="<?= htmlspecialchars($ramoEdit['emoji']) ?>" maxlength="4">
        </div>
        <div class="form-group">
          <label>Nombre</label>
          <input type="text" name="nombre" value="<?= htmlspecialchars($ramoEdit['nombre']) ?>" required>
        </div>
        <div class="form-group">
          <label>Descripción</label>
          <input type="text" name="descripcion" value="<?= htmlspecialchars($ramoEdit['descripcion']) ?>">
        </div>
        <div class="form-group">
          <label>Precio ($)</label>
          <input type="number" name="precio" value="<?= $ramoEdit['precio'] ?>" min="1" step="0.01" required>
        </div>
        <div class="form-group">
          <label>Imagen del ramo (opcional)</label>
          <?php if ($ramoEdit['imagen']): ?>
            <img src="uploads/<?= htmlspecialchars($ramoEdit['imagen']) ?>" style="height:80px;border-radius:10px;margin-bottom:8px;display:block;">
          <?php endif; ?>
          <input type="file" name="imagen" accept="image/*" style="padding:8px;">
          <p style="font-size:12px;color:var(--texto-muted);margin-top:4px;">JPG, PNG, WEBP. Si no subes imagen se usará el emoji.</p>
        </div>
        <button type="submit" class="btn-main">Guardar cambios</button>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <div class="table-wrap">
    <div class="table-header"><h3>🌸 Gestión de Ramos</h3></div>
    <table>
      <thead><tr><th>Emoji</th><th>Nombre</th><th>Precio</th><th>Stock</th><th>Imagen</th><th>Acción</th></tr></thead>
      <tbody>
        <?php foreach ($ramos as $r): ?>
        <tr>
          <td style="font-size:24px;"><?= $r['emoji'] ?></td>
          <td>
            <strong><?= htmlspecialchars($r['nombre']) ?></strong>
            <div style="font-size:12px;color:var(--texto-muted);"><?= htmlspecialchars($r['descripcion']) ?></div>
          </td>
          <td>$<?= number_format($r['precio'],2) ?></td>
          <td><?= $r['stock'] ?></td>
          <td><?= $r['imagen'] ? '✅ Sí' : '❌ No' ?></td>
          <td><a href="admin.php?tab=catalogo&editar=<?= $r['id'] ?>" class="btn-sm btn-outline-rosa">Editar</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

</div>

<script>
const al = document.getElementById('alert-msg');
if (al) setTimeout(() => al.style.opacity = '0', 4000);
</script>
</body>
</html>
