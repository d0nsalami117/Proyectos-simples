-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 04-06-2026 a las 18:47:47
-- Versión del servidor: 8.0.31
-- Versión de PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `floreria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE IF NOT EXISTS `pedidos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `ramo_id` int NOT NULL,
  `cantidad` int NOT NULL DEFAULT '1',
  `total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `estado` enum('pendiente','completado','cancelado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `creado_en` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `ramo_id` (`ramo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `usuario_id`, `ramo_id`, `cantidad`, `total`, `estado`, `creado_en`) VALUES
(1, 3, 10, 2, '620.00', 'completado', '2026-06-04 12:45:46');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ramos`
--

DROP TABLE IF EXISTS `ramos`;
CREATE TABLE IF NOT EXISTS `ramos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `emoji` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '?',
  `precio` decimal(10,2) NOT NULL DEFAULT '0.00',
  `stock` int NOT NULL DEFAULT '0',
  `stock_max` int NOT NULL DEFAULT '50',
  `imagen` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `creado_en` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ramos`
--

INSERT INTO `ramos` (`id`, `nombre`, `descripcion`, `emoji`, `precio`, `stock`, `stock_max`, `imagen`, `activo`, `creado_en`) VALUES
(1, 'Ramo Eterno', 'Rosas rojas premium, símbolo del amor eterno', '🌹', '350.00', 35, 55, NULL, 1, '2026-06-04 12:18:05'),
(2, 'Primavera Rosa', 'Mix de flores primaverales en tonos rosa y blanco', '🌸', '280.00', 28, 48, NULL, 1, '2026-06-04 12:18:05'),
(3, 'Girasoles Alegres', 'Girasoles naturales llenos de vida y color', '🌻', '220.00', 40, 60, NULL, 1, '2026-06-04 12:18:05'),
(4, 'Tulipanes Holandeses', 'Tulipanes importados, colores vivos y elegantes', '🌷', '310.00', 43, 63, NULL, 1, '2026-06-04 12:18:05'),
(5, 'Bouquet Nupcial', 'Arreglo elegante para bodas y eventos especiales', '💐', '680.00', 6, 20, NULL, 1, '2026-06-04 12:18:05'),
(6, 'Lirios Blancos', 'Lirios de pureza y elegancia, ideal para regalar', '🤍', '290.00', 20, 40, NULL, 1, '2026-06-04 12:18:05'),
(7, 'Ramo Eterno', 'Rosas rojas premium, símbolo del amor eterno', '🌹', '350.00', 15, 50, NULL, 1, '2026-06-04 12:18:39'),
(8, 'Primavera Rosa', 'Mix de flores primaverales en tonos rosa y blanco', '🌸', '280.00', 8, 40, NULL, 1, '2026-06-04 12:18:39'),
(9, 'Girasoles Alegres', 'Girasoles naturales llenos de vida y color', '🌻', '220.00', 20, 40, NULL, 1, '2026-06-04 12:18:39'),
(10, 'Tulipanes Holandeses', 'Tulipanes importados, colores vivos y elegantes', '🌷', '310.00', 21, 41, NULL, 1, '2026-06-04 12:18:39'),
(11, 'Bouquet Nupcial', 'Arreglo elegante para bodas y eventos especiales', '💐', '680.00', 6, 20, NULL, 1, '2026-06-04 12:18:39'),
(12, 'Lirios Blancos', 'Lirios de pureza y elegancia, ideal para regalar', '🤍', '290.00', 20, 40, NULL, 1, '2026-06-04 12:18:39');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('admin','cliente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cliente',
  `creado_en` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `telefono`, `password`, `rol`, `creado_en`) VALUES
(1, 'Admin', '3310000000', '$2y$10$xf8xq3m9ZThiJS1c/2ZaReLw0PJzddkOkOsNosV9./HO3PBomPrLy', 'admin', '2026-06-04 12:18:05'),
(3, 'Florencia', '3312345', '$2y$10$QJx7VazSESYGzU4opMSqqu8VI5/dqhfh7SWODupplsVZZjE1Pk9gi', 'cliente', '2026-06-04 12:45:13');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`ramo_id`) REFERENCES `ramos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
