<?php
// ============================================================
//  db.php – Conexión a MySQL
//  Ajusta DB_USER / DB_PASS si tu WAMP tiene otro usuario
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'Donsalami');       // usuario por defecto en WAMP
define('DB_PASS', '6hVebwYD00?');           // contraseña vacía por defecto en WAMP
define('DB_NAME', 'floreria');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}
