<?php
// ============================================================
//  index.php – Catálogo para clientes
// ============================================================
session_start();
if (!isset($_SESSION['usuario_id'])) { header('Location: login.php'); exit; }
if ($_SESSION['rol'] === 'admin')    { header('Location: admin.php'); exit; }

require_once 'db.php';
$db = getDB();

// ── Procesar pedido (POST) ──────────────────────────────────
$msg_ok  = '';
$msg_err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ramo_id'], $_POST['cantidad'])) {
    $ramoId  = (int)$_POST['ramo_id'];
    $cant    = max(1, (int)$_POST['cantidad']);
    $userId  = $_SESSION['usuario_id'];

    $ramo = $db->prepare('SELECT * FROM ramos WHERE id = ? AND activo = 1 LIMIT 1');
    $ramo->execute([$ramoId]);
    $ramo = $ramo->fetch();

    if (!$ramo) {
        $msg_err = 'El ramo no existe.';
    } elseif ($ramo['stock'] < $cant) {
        $msg_err = 'No hay suficiente stock. Solo quedan ' . $ramo['stock'] . ' unidades.';
    } else {
        $total = $ramo['precio'] * $cant;
        $db->prepare('INSERT INTO pedidos (usuario_id, ramo_id, cantidad, total) VALUES (?,?,?,?)')
           ->execute([$userId, $ramoId, $cant, $total]);
        $db->prepare('UPDATE ramos SET stock = stock - ? WHERE id = ?')
           ->execute([$cant, $ramoId]);
        $msg_ok = "¡Pedido realizado! {$cant} ramo(s) de \"{$ramo['nombre']}\" por $" . number_format($total, 2) . " MXN.";
    }
}

// ── Obtener ramos activos ───────────────────────────────────
$ramos = $db->query('SELECT * FROM ramos WHERE activo = 1 ORDER BY id')->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Flor & Alma – Catálogo</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="nav-logo"><span>💐</span> Flor &amp; Alma</div>
  <div class="nav-links">
    <div class="nav-user">
      <div class="avatar"><?= strtoupper(mb_substr($_SESSION['nombre'], 0, 1)) ?></div>
      <span><?= htmlspecialchars($_SESSION['nombre']) ?></span>
    </div>
    <a href="logout.php" class="nav-btn logout">Salir 👋</a>
  </div>
</nav>

<div class="page-content">

  <!-- HERO -->
  <div class="hero-banner">
    <h2>Catálogo de Ramos</h2>
    <p>Elige el arreglo perfecto para cada momento especial ✨</p>
  </div>

  <!-- MENSAJES -->
  <?php if ($msg_ok):  ?><div class="alert alert-ok" id="alert-msg">🌸 <?= htmlspecialchars($msg_ok) ?></div><?php endif; ?>
  <?php if ($msg_err): ?><div class="alert alert-err" id="alert-msg">⚠️ <?= htmlspecialchars($msg_err) ?></div><?php endif; ?>

  <h3 class="section-title">🌸 Nuestros Ramos</h3>

  <div class="products-grid">
    <?php foreach ($ramos as $r):
      if ($r['stock'] === 0)     { $badge = 'Sin stock';              $bClass = 'stock-out'; }
      elseif ($r['stock'] <= 5)  { $badge = 'Solo '.$r['stock'].' left'; $bClass = 'stock-low'; }
      else                       { $badge = $r['stock'].' disponibles'; $bClass = 'stock-ok'; }
      $sinStock = ($r['stock'] === 0);
    ?>
    <div class="product-card <?= $sinStock ? 'card-disabled' : '' ?>">
      <div class="product-img">
        <?php if ($r['imagen']): ?>
          <img src="uploads/<?= htmlspecialchars($r['imagen']) ?>" alt="<?= htmlspecialchars($r['nombre']) ?>">
        <?php else: ?>
          <span class="placeholder-emoji"><?= $r['emoji'] ?></span>
        <?php endif; ?>
        <span class="stock-badge <?= $bClass ?>"><?= $badge ?></span>
      </div>
      <div class="product-info">
        <div class="product-name"><?= htmlspecialchars($r['nombre']) ?></div>
        <div class="product-desc"><?= htmlspecialchars($r['descripcion']) ?></div>
        <div class="product-footer">
          <div class="product-price">$<?= number_format($r['precio'], 2) ?> <span>MXN</span></div>
          <?php if (!$sinStock): ?>
            <button class="btn-add" onclick="openModal(<?= $r['id'] ?>, '<?= addslashes($r['nombre']) ?>', '<?= $r['emoji'] ?>', <?= $r['precio'] ?>, <?= $r['stock'] ?>, '<?= addslashes($r['descripcion']) ?>')">
              Pedir 🌸
            </button>
          <?php else: ?>
            <button class="btn-add" disabled>Sin stock</button>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- MODAL PEDIDO -->
<div class="modal-overlay" id="modal-order">
  <div class="modal">
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h3>Hacer pedido</h3>
    <div class="modal-product-preview">
      <span class="preview-emoji" id="m-emoji">💐</span>
      <div class="preview-info">
        <h4 id="m-name">Ramo</h4>
        <p id="m-desc">Descripción</p>
        <p id="m-stock" style="font-size:12px; color:var(--rosa-oscuro); margin-top:4px;"></p>
      </div>
    </div>
    <form method="POST" action="index.php" id="order-form">
      <input type="hidden" name="ramo_id" id="m-ramo-id">
      <div class="qty-control">
        <label>Cantidad de ramos:</label>
        <div class="qty-btns">
          <button type="button" class="qty-btn" onclick="changeQty(-1)">−</button>
          <span id="m-qty">1</span>
          <button type="button" class="qty-btn" onclick="changeQty(1)">+</button>
        </div>
      </div>
      <input type="hidden" name="cantidad" id="m-qty-input" value="1">
      <div class="modal-total">
        <span>Total a pagar</span>
        <strong id="m-total">$0</strong>
      </div>
      <button type="submit" class="btn-main">Confirmar pedido 🌸</button>
    </form>
  </div>
</div>

<script>
let modalData = { precio: 0, stock: 0, qty: 1 };

function openModal(id, nombre, emoji, precio, stock, desc) {
  modalData = { precio, stock, qty: 1 };
  document.getElementById('m-ramo-id').value = id;
  document.getElementById('m-emoji').textContent = emoji;
  document.getElementById('m-name').textContent  = nombre;
  document.getElementById('m-desc').textContent  = desc;
  document.getElementById('m-stock').textContent = 'Disponibles: ' + stock + ' ramos';
  updateModal();
  document.getElementById('modal-order').classList.add('open');
}
function closeModal() { document.getElementById('modal-order').classList.remove('open'); }
function changeQty(d) {
  const nq = modalData.qty + d;
  if (nq < 1 || nq > modalData.stock) return;
  modalData.qty = nq;
  updateModal();
}
function updateModal() {
  document.getElementById('m-qty').textContent       = modalData.qty;
  document.getElementById('m-qty-input').value       = modalData.qty;
  document.getElementById('m-total').textContent     = '$' + (modalData.precio * modalData.qty).toLocaleString('es-MX', {minimumFractionDigits:2});
}
document.getElementById('modal-order').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeModal();
});

// Auto-ocultar alertas
const al = document.getElementById('alert-msg');
if (al) setTimeout(() => al.style.opacity = '0', 4000);
</script>
</body>
</html>
